import json
from anthropic import Anthropic
from tokenizers import Tokenizer
from transformers import AutoTokenizer
import tiktoken
import boto3
import traceback
import time
from botocore.config import Config

APP_MD    = json.load(open('application_metadata_complete.json', 'r'))
REGION    = APP_MD['region']

try:
    DYNAMODB_TABLE=APP_MD['dynamodb_table']
    DYNAMODB_USER=APP_MD['dynamodb_user']
except:
    DYNAMODB_TABLE=""
DYNAMODB      = boto3.resource('dynamodb',region_name=REGION)


PARENT_TEMPLATE_PATH="prompt_template"
MODELS = ["claude","llama","cohere","ai21","titan","mistral"]
PERSONA_DICT = {
    "General":"assistant",
    "Finance":"finanacial analyst",
    "Insurance":"insurance analyst",
    "Medical":"medical expert"
}


config = Config(
    read_timeout=600,
    retries = dict(
        max_attempts = 10
    )
)


SAGEMAKER     = boto3.client('sagemaker-runtime', region_name=REGION)
BEDROCK = boto3.client(service_name='bedrock-runtime',region_name='us-east-1', config=config)

def load_summ_prompt(params):
    chosen_model=[x for x in MODELS if x in params['model_name'].lower()][0]
    with open(f"{PARENT_TEMPLATE_PATH}/summary/{chosen_model}/{params['persona'].lower()}.txt","r") as f:
        prompt_template=f.read()
    prompt =prompt_template.format(doc=params['context'])
    if "claude" in params['model_name'].lower():
        prompt=f"\n\nHuman:\n{prompt}\n\nAssistant:"
    
    return prompt

def load_qa_prompt(params):
    chosen_model=[x for x in MODELS if x in params['model_name'].lower()][0]
    with open(f"{PARENT_TEMPLATE_PATH}/rag/{chosen_model}/prompt1.txt","r") as f:
        prompt_template=f.read()
    
    prompt =prompt_template.format(doc=params['context'], 
                                   prompt=params['question'],
                                   role=PERSONA_DICT[params['persona']])
    if "claude" in params['model_name'].lower():
        prompt=f"\n\nHuman:\n{prompt}\n\nAssistant:"
    return prompt


def doc_qna_endpoint(endpoint, responses,prompt,params, handler=None):
    """This function implements the retrieval technique selected for each retriever, collects retrieved passage metadata and queries the 
        Text generation LLm endpoint.
    """
    total_response=[]  
    
    # If auto retriever technique is selected, the an interim LLM call is made to check the quality of a single retrieved passage
    if params["auto_rtv"]:          
        passage = responses['ResultItems'][0]['Content']
        q_c=retrieval_quality_check(passage, prompt)
        # If the single passage contains sufficient information, pass to the final LLM to get a response
        if "yes" in q_c:
            params["K"]=1
            total_response=single_passage_retrieval(responses,prompt,params, handler)                      
            return total_response
        else:
            # If not, call the full_page_retriever technique with topK=3
            params["K"]=3
            answer1=full_page_retrieval_technique_kendra(responses,prompt,params, handler)
            total_response.append(answer1)
            return total_response
    
    else:
        if "Kendra" in params["rag"]:
            if 'combined-passages' in params['method']:
                answer1=combined_passages_retrieval_technique(responses,prompt,params, handler)
                total_response.append(answer1)
                return total_response
            elif 'full-pages' in params['method']:            
                answer1=full_page_retrieval_technique_kendra(responses,prompt,params, handler)
                total_response.append(answer1)
                return total_response
            elif 'single-passages' in params['method']:
                total_response=single_passage_retrieval(responses,prompt,params, handler)
                return total_response

        elif "OpenSearch" in params["rag"]:
            if 'single-passages'  in params['method']:
                total_response=single_passage_retrieval(responses,prompt,params, handler)
                return total_response
            elif 'combined-passages' or 'full-pages' in params['method']:
                answer1=combined_passages_retrieval_technique(responses,prompt,params, handler)
                total_response.append(answer1)
                return total_response

def _get_tokenizer(model_name):
    '''
    model_name: model name in params, need to be in lower case
    '''
    if "claude" in model_name:
        tokenizer = Anthropic()
    elif "llama" in model_name:
        tokenizer = AutoTokenizer.from_pretrained('meta-llama/Llama-2-13b-chat-hf', token=APP_MD['hugginfacekey'])
        ## TODO: replace huggingfacekey
    elif "cohere" in model_name:
        tokenizer = Tokenizer.from_pretrained("Cohere/command-nightly")
    elif "ai21" in model_name:
        #replace with AI21 tokenizer
        tokenizer = tiktoken.get_encoding('cl100k_base')
    elif "titan" in model_name:
        tokenizer = tiktoken.get_encoding('cl100k_base')
    elif "mistral" in model_name:
        tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-v0.1", token=APP_MD['hugginfacekey'])
    
    return tokenizer



def count_tokens(model_name, tokenizer, text):
    '''
    model_name: model name in params, need to be in lower case
    '''
    if tokenizer is None:
        tokenizer = _get_tokenizer(model_name)
    
    if "claude" in model_name:
        token_length=tokenizer.count_tokens(text)
    elif "llama" in model_name:
        token_length=len(tokenizer.encode(text))
    elif "cohere" in model_name:
        token_length=len(tokenizer.encode(text))
    elif "ai21" in model_name:
        token_length=len(tokenizer.encode(text))
    elif "titan" in model_name:
        token_length=len(tokenizer.encode(text))
    elif "mistral" in model_name:
        token_length=len(tokenizer.encode(text))
    
    return token_length


def _get_endpoint_prompt(params, qa_prompt):
    if 'ai21' in params['model_name'].lower():
        prompt={
          "prompt":  qa_prompt,
          "maxTokens": params['max_len'],
          "temperature": round(params['temp'],2),
          "topP":  params['top_p'], 
        }
    elif 'claude3' in params['model_name'].lower():
        prompt={
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": params['max_len'],
            "messages": [
                    {
                        "role": 'user',
                        "content": [
                            # {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": None}},
                            {"type": "text", "text": qa_prompt}
                        ]
                    }
                ],
            "temperature": params['temp'],
            "top_p": params['top_p'],
            "system": ''
        }
    elif 'claude' in params['model_name'].lower():
        prompt={
          "prompt": qa_prompt,
          "max_tokens_to_sample": round(params['max_len']),
          "temperature": params['temp'],
          "top_k": 250,
          "top_p":params['top_p'],  
             "stop_sequences": []
        }
    elif 'titan' in params['model_name'].lower():   
        prompt={
               "inputText": qa_prompt,
               "textGenerationConfig": {
                   "maxTokenCount": params['max_len'],     
                   "temperature":params['temp'],
                   "topP":params['top_p'],  
                   },
            }
    elif 'cohere' in params['model_name'].lower():
        prompt={
          "prompt": qa_prompt,
          "max_tokens": round(params['max_len']), 
          "temperature": params['temp'], 
          "return_likelihoods": "GENERATION"   
        }
    elif 'mistral' in params['model_name'].lower():
        prompt = {
               "inputs": qa_prompt,
                "parameters": {"max_new_tokens": params['max_len'], 
                               "top_p": params['top_p'] if params['top_p']<1 else 0.99 ,
                               "temperature": params['temp'] if params['temp']>0 else 0.01,
                               "return_full_text": False,}
            }
    elif 'llama2' in params['model_name'].lower():
        if "bedrock" in params['model_name'].lower():
            prompt={
              "prompt": qa_prompt,
                    "max_gen_len":params['max_len'], 
                    "temperature":params['temp'] if params['temp']>0 else 0.01,
                    "top_p": params['top_p'] if params['top_p']<1 else 0.99 
            }
            
        else:            
            prompt = {
               "inputs": qa_prompt,
                "parameters": {"max_new_tokens": params['max_len'], 
                               "top_p": params['top_p'] if params['top_p']<1 else 0.99 ,
                               "temperature": params['temp'] if params['temp']>0 else 0.01,
                               "return_full_text": False,}
            }
    
    prompt=json.dumps(prompt)
    return prompt

def _get_endpoint_response(params, prompt):
    if 'ai21' in params['model_name'].lower():
        response = BEDROCK.invoke_model(body=prompt,
                                modelId=params['endpoint-llm'], 
                                accept="application/json", 
                                contentType="application/json")
        is_streaming = False
    elif 'mistral' in params['model_name'].lower():
        response = SAGEMAKER.invoke_endpoint(Body=prompt, 
                                         EndpointName=params['endpoint-llm'],
                                         ContentType="application/json")
        is_streaming = False
    elif 'llama2' in params['model_name'].lower() and \
        "bedrock" not in params['model_name'].lower(): 
        response = SAGEMAKER.invoke_endpoint(Body=prompt, 
                                         EndpointName=params['endpoint-llm'],
                                         ContentType="application/json",
                                         CustomAttributes='accept_eula=true')
        is_streaming = False
    elif params['streaming']:
        # for claude, titan, cohere, llama2-bedrock
        response = BEDROCK.invoke_model_with_response_stream(body=prompt, 
                                                             modelId=params['endpoint-llm'], 
                                                             accept="application/json",  
                                                             contentType="application/json")
        is_streaming = True
    else:
        response = BEDROCK.invoke_model(body=prompt,
                            modelId=params['endpoint-llm'], 
                            accept="application/json", 
                            contentType="application/json")
        is_streaming = False
    
    return response, is_streaming

def _llm_streamer(stream, model_name, handler=None):
    answer = ""
    if stream:
        try: 
            for event in stream:
                chunk = event.get('chunk')
                if chunk:
                    print("streaming call answer:\t" + answer)
                    chunk_obj = json.loads(chunk.get('bytes').decode())
                    if 'claude' in model_name:
                        text = chunk_obj['completion']
                    elif 'titan' in model_name:
                        text = chunk_obj["outputText"]
                    elif 'cohere' in model_name:
                        text = chunk_obj["generations"][0]['text']
                    elif 'llama2' in model_name:
                        text = chunk_obj["generation"]

                    answer+=text
                    time.sleep(5)
                    if handler is not None:
                        handler.markdown(answer.replace("$","USD ").replace("%", " percent"))
        except:
            # printing stack trace 
            traceback.print_exc()
        
    return answer
    
def _extract_answer(params, response, is_streaming, handler):
    model_name = params['model_name'].lower()
    if is_streaming:
        # bedrock streaming output
        stream = response.get('body')
        answer = _llm_streamer(stream, model_name, handler)
    else:
        if 'Body' in response:
            ## Sagemaker output for llama
            answer=json.loads(response['Body'].read().decode())[0]['generated_text']
        elif 'body' in response:
            # bedrock output
            answer=response['body'].read().decode()
            answer=json.loads(answer)
            if 'cohere' in model_name:
                answer = answer["generations"][0]['text']
            elif 'claude' in model_name:
                if 'claude3' in model_name:
                    ## claude 3 supports message api
                    answer = answer['content'][0]['text']
                else:
                    ## claude 2 supports completion api
                    answer=answer['completion']

            elif "ai21" in model_name:
                # no streaming
                answer=answer['completions'][0]['data']['text']
            elif 'titan' in model_name:
                answer=answer['results'][0]['outputText']
            elif 'llama2' in model_name:
                answer=answer['generation']
    
    return answer

def query_endpoint(params, qa_prompt, handler=None):
    """
    Function to query the LLM endpoint and count tokens in and out.
    """
    prompt = _get_endpoint_prompt(params, qa_prompt)
    response, is_streaming = _get_endpoint_response(params, prompt)
    answer = _extract_answer(params, response, is_streaming, handler)
    
    model_name = params['model_name'].lower()
    tokenizer = _get_tokenizer(model_name)
    # if 'ai21' in model_name:
    #     input_token_len = count_tokens(model_name, tokenizer, qa_prompt)
    #     output_token_len = count_tokens(model_name, tokenizer, answer)
    #     tokens_len = input_token_len + output_token_len
    # else:
    tokens_len = count_tokens(model_name, tokenizer, f"{qa_prompt} {answer}")
    
    return answer, tokens_len


def llm_memory(question, params=None, chat_memory = None):
    """ This function determines the context of each new question looking at the conversation history...
        to send the appropiate question to the retriever.    
        Messages are stored in DynamoDb if a table is provided or in memory, in the absence of a provided DynamoDb table
    """
    chat_string = ""
    if chat_memory is not None and isinstance(chat_memory, list) and len(chat_memory) > 0:
        for entry in chat_memory:
            print(entry)
            chat_string += f"user -- {entry['user']}\nyou -- {entry['assistant']}\n"
    elif DYNAMODB_TABLE:
        chat_histories = DYNAMODB.Table(DYNAMODB_TABLE).get_item(Key={"UserId": DYNAMODB_USER})
        if "Item" in chat_histories:
            for entry in chat_histories['Item']['messages']:
                chat_string += f"user -- {entry['user']}\nyou -- {entry['assistant']}\n"
    
    memory_template = f"""Here is the history of your conversation dialogue with a user:
<history>
{chat_string}
</history>

Here is a new question from the user:
user: {question}

Your task is to determine if the question is a follow-up to the previous conversation:
<steps>
- If it is, rephrase the question as an independent and concise question while retaining the original intent.
- If it is not, respond with "no__no".
</steps>

Format your response as:
<response>
answer
</response>

please follow the steps and guildline above to rephrase the new questions, and your response should still be a question.
Remember, your role is not to answer the question!
"""
    
    if chat_string and len(chat_string) > 0:
        prompt = memory_template.format(chat_string = chat_string, question = question)
        if params is None:
            pass
            # LangChain solution
            
            # from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
            # from langchain_community.llms import Bedrock
            # inference_modifier = {'max_tokens_to_sample':70, 
            #                       "temperature":0.1,                   
            #                      }
            # llm = Bedrock(model_id='anthropic.claude-instant-v1', client=BEDROCK, model_kwargs = inference_modifier,
            #               streaming=False,  # Toggle this to turn streaming on or off
            #               callbacks=[StreamingStdOutCallbackHandler() ])
            # prompt=f"\n\nHuman:\n{prompt}\n\nAssistant:"
            # answer=llm(prompt)
        else:
            if "claude" in params['model_name'].lower():
                prompt=f"\n\nHuman:\n{prompt}\n\nAssistant:"
            
            endpoint_prompt = _get_endpoint_prompt(params, prompt)
            endpoint_llm = params['endpoint-llm']
            params['endpoint-llm'] = "anthropic.claude-v2:1"
            response, is_streaming = _get_endpoint_response(params, endpoint_prompt)
            params['endpoint-llm'] = endpoint_llm
            answer = _extract_answer(params, response, is_streaming, None)
        
        idx1 = answer.index('<response>')
        idx2 = answer.index('</response>')
        question_2=answer[idx1 + len('<response>') + 1: idx2]
        if 'no__no' not in question_2:
            question = question_2
        
        print(question)
    
    return question

def put_db(messages):
    """Store long term chat history in DynamoDB"""
    
    chat_item = {
        "UserId": DYNAMODB_USER,
        "messages": [messages]  # Assuming 'messages' is a list of dictionaries
    }
    
    # Check if the user already exists in the table
    existing_item = DYNAMODB.Table(DYNAMODB_TABLE).get_item(Key={"UserId": DYNAMODB_USER})
    
    # If the user exists, append new messages to the existing ones
    if "Item" in existing_item:
        existing_messages = existing_item["Item"]["messages"]
        chat_item["messages"] = existing_messages + [messages]
    
    response = DYNAMODB.Table(DYNAMODB_TABLE).put_item(
        Item=chat_item
    ) 

    

def check_chunking_needed(model_name, text):
    '''
    model_name: model name in params, need to be in lower case
    '''
    token_length = count_tokens(model_name, None, text)
    
    if "claude" in model_name:
        chunking_needed=token_length>90000
    elif "llama" in model_name:
        chunking_needed=token_length>3000
    elif "cohere" in model_name:
        chunking_needed=token_length>3000
    elif "ai21" in model_name:
        chunking_needed=token_length>6000
    elif "titan" in model_name:
        chunking_needed=token_length>6000
    elif "mistral" in model_name:
        chunking_needed=token_length>7000
    
    return chunking_needed



def summarize_section(payload):
    """
    Initial summary of chunks
    """
    prompt = load_summ_prompt(payload)
    # payload['prompt'] = prompt ### payload['prompt'] isn't used in query_endpoint
    response, tokens= query_endpoint(payload, prompt)
    return response, tokens
  
def summarize_final(payload, handler=None):
    """
    Final summary of of all chunks summary
    """
    prompt = load_summ_prompt(payload)
    # payload['prompt'] = prompt ### payload['prompt'] isn't used in query_endpoint
    response,tokens = query_endpoint(payload, prompt, handler)
    return response, tokens


def first_summ(params, section):
    """
    Function to call initial summary of chunks.
    this function is run in parallel to the number of chunks
    """
    params['context']= section
    summaries, tokens = summarize_section(params)    
    return summaries, tokens